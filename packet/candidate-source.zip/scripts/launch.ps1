param(
    [ValidateSet("auto", "docker", "podman")]
    [string] $Engine = "auto",

    [ValidateRange(1, 65535)]
    [Nullable[int]] $Port = $null,

    [int] $TimeoutSeconds = 180,

    [ValidateSet("off", "auto", "on")]
    [string] $Gpu = "off",

    [int] $SessionMaxHours = $(if ($env:TOWERSCOUT_SESSION_MAX_HOURS) { [int] $env:TOWERSCOUT_SESSION_MAX_HOURS } else { 12 }),

    [string] $PodmanMachineName = "",

    [switch] $Build,

    [switch] $NoBrowser
)

$ErrorActionPreference = "Stop"
$portWasSpecified = $PSBoundParameters.ContainsKey("Port")

function Get-TowerScoutPropertyValue {
    param(
        [object] $InputObject,

        [Parameter(Mandatory = $true)]
        [string] $Name
    )

    if ($null -eq $InputObject) {
        return $null
    }
    if ($InputObject.PSObject.Properties.Name -notcontains $Name) {
        return $null
    }
    return $InputObject.PSObject.Properties[$Name].Value
}

function Get-TowerScoutReadiness {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Url
    )

    try {
        $request = [System.Net.HttpWebRequest]::Create($Url)
        $request.Timeout = 5000
        try {
            $response = $request.GetResponse()
        }
        catch [System.Net.WebException] {
            if ($_.Exception.Response -eq $null) {
                throw
            }
            $response = $_.Exception.Response
        }

        $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
        try {
            $body = $reader.ReadToEnd()
        }
        finally {
            $reader.Close()
            $response.Close()
        }

        $payload = $body | ConvertFrom-Json
        return [pscustomobject]@{
            Reachable = $true
            State = [string] $payload.state
            Payload = $payload
            Error = $null
        }
    }
    catch {
        return [pscustomobject]@{
            Reachable = $false
            State = "unreachable"
            Payload = $null
            Error = $_.Exception.Message
        }
    }
}

function Write-TowerScoutReadinessSummary {
    param(
        [Parameter(Mandatory = $true)]
        [object] $Readiness
    )

    if (-not $Readiness.Reachable) {
        Write-Host "TowerScout is not reachable yet. The container may still be starting."
        return
    }

    $payload = $Readiness.Payload
    Write-Host "TowerScout readiness state: $($Readiness.State)"
    switch ($Readiness.State) {
        "setup_required" {
            Write-Host "Next action: complete Setup Wizard or Settings with one valid Google Maps or Azure Maps provider key."
        }
        "degraded" {
            Write-Host "Next action: follow the recovery hints below. During first setup, this usually means importing the Model & Data Package assets."
        }
        "ready" {
            Write-Host "Next action: TowerScout is ready for normal use."
        }
        "fatal" {
            Write-Host "Next action: stop validation and collect support evidence with scripts\status.cmd and scripts\logs.cmd."
        }
        default {
            Write-Host "Next action: keep this PowerShell window open while TowerScout continues starting."
        }
    }
    $components = Get-TowerScoutPropertyValue -InputObject $payload -Name "components"
    $assets = Get-TowerScoutPropertyValue -InputObject $components -Name "assets"
    $assetStatus = Get-TowerScoutPropertyValue -InputObject $assets -Name "status"
    if ($assetStatus) {
        Write-Host "Asset status: $assetStatus"
    }
    $config = Get-TowerScoutPropertyValue -InputObject $components -Name "config"
    $configStatus = Get-TowerScoutPropertyValue -InputObject $config -Name "status"
    if ($configStatus) {
        Write-Host "Config status: $configStatus"
    }
    $runtime = Get-TowerScoutPropertyValue -InputObject $payload -Name "runtime"
    if ($runtime) {
        Write-Host (
            "Runtime: engine={0} device_policy={1} selected_device={2} pytorch_flavor={3}" -f
            (Get-TowerScoutPropertyValue -InputObject $runtime -Name "container_engine"),
            (Get-TowerScoutPropertyValue -InputObject $runtime -Name "device_policy"),
            (Get-TowerScoutPropertyValue -InputObject $runtime -Name "selected_device"),
            (Get-TowerScoutPropertyValue -InputObject $runtime -Name "pytorch_flavor")
        )
    }
    $version = Get-TowerScoutPropertyValue -InputObject $payload -Name "version"
    $imageDigest = Get-TowerScoutPropertyValue -InputObject $version -Name "image_digest"
    if ($imageDigest) {
        Write-Host "Image digest: $imageDigest"
    }
    $recovery = Get-TowerScoutPropertyValue -InputObject $payload -Name "recovery"
    if ($recovery) {
        foreach ($item in $recovery) {
            Write-Host "Recovery: $item"
        }
    }
}

function Test-TowerScoutCudaSelected {
    param(
        [Parameter(Mandatory = $true)]
        [object] $Readiness
    )

    if (-not $Readiness.Reachable -or $null -eq $Readiness.Payload) {
        return $false
    }

    $payload = $Readiness.Payload
    $selectedDevice = ""
    $runtime = Get-TowerScoutPropertyValue -InputObject $payload -Name "runtime"
    $runtimeSelectedDevice = Get-TowerScoutPropertyValue -InputObject $runtime -Name "selected_device"
    if ($runtimeSelectedDevice) {
        $selectedDevice = [string] $runtimeSelectedDevice
    }
    else {
        $components = Get-TowerScoutPropertyValue -InputObject $payload -Name "components"
        $mlRuntime = Get-TowerScoutPropertyValue -InputObject $components -Name "ml_runtime"
        $mlRuntimeSelectedDevice = Get-TowerScoutPropertyValue -InputObject $mlRuntime -Name "selected_device"
        if ($mlRuntimeSelectedDevice) {
            $selectedDevice = [string] $mlRuntimeSelectedDevice
        }
    }

    return $selectedDevice.Trim().ToLowerInvariant() -eq "cuda"
}

function Write-TowerScoutHostDiagnostics {
    param(
        [Parameter(Mandatory = $true)]
        [string] $EngineName
    )

    if ($env:OS -ne "Windows_NT") {
        return
    }

    Write-Host ""
    Write-Host "Windows container runtime diagnostics:"

    $wslCommand = Get-Command "wsl.exe" -ErrorAction SilentlyContinue
    if ($null -eq $wslCommand) {
        Write-Host "- wsl.exe was not found. Docker Desktop or Podman on Windows usually needs WSL2 or Hyper-V/virtualization support."
    }
    else {
        Write-Host "- wsl.exe found at $($wslCommand.Source)."
        try {
            $wslStatus = & wsl.exe --status 2>&1
            foreach ($line in $wslStatus) {
                $normalizedLine = ([string] $line).Replace([string][char]0, "")
                if (-not [string]::IsNullOrWhiteSpace($normalizedLine)) {
                    Write-Host "  $normalizedLine"
                }
            }
        }
        catch {
            Write-Host "  Could not read WSL status: $($_.Exception.Message)"
        }
    }

    if ($EngineName -eq "podman") {
        Write-Host "- For Podman, check the machine state with: podman machine list"
        try {
            $podmanMachine = & podman machine list 2>&1
            foreach ($line in $podmanMachine) {
                $normalizedLine = ([string] $line).Replace([string][char]0, "")
                if (-not [string]::IsNullOrWhiteSpace($normalizedLine)) {
                    Write-Host "  $normalizedLine"
                }
            }
        }
        catch {
            Write-Host "  Could not read Podman machine state: $($_.Exception.Message)"
        }
    }

    if ($EngineName -eq "docker") {
        Write-Host "- For Docker Desktop, confirm Docker Desktop is running and that its WSL2 or Hyper-V backend is healthy."
    }

    Write-Host "- If the engine is managed by local IT, confirm virtualization, WSL2/Hyper-V, endpoint policy, and Compose provider access are approved."
}

function Invoke-TowerScoutLaunchRuntime {
    param(
        [Parameter(Mandatory = $true)]
        [string] $EngineName,

        [Parameter(Mandatory = $true)]
        [string] $GpuMode,

        [Parameter(Mandatory = $true)]
        [int] $AppPort,

        [Parameter(Mandatory = $true)]
        [string] $RootPath,

        [Parameter(Mandatory = $true)]
        [string] $PackageFlavor,

        [Parameter(Mandatory = $true)]
        [string] $AppUrl,

        [Parameter(Mandatory = $true)]
        [string] $ReadinessUrl,

        [Parameter(Mandatory = $true)]
        [int] $ReadinessTimeoutSeconds,

        [string] $PodmanMachineName = "",

        [switch] $Build,

        [switch] $HostHelperReviewEnabled,

        [switch] $NoBrowser
    )

    $hostHelperReviewSession = $null
    $launchSucceeded = $false
    $helperControlledOperation = [string]::Equals(
        [string] $env:TOWERSCOUT_HOST_HELPER_CONTROLLED_OPERATION,
        "1",
        [System.StringComparison]::Ordinal
    )
    try {
        if ($HostHelperReviewEnabled -and -not $helperControlledOperation) {
            $hostHelperReviewSession = Initialize-TowerScoutHostHelperReviewSession `
                -EngineName $EngineName `
                -GpuMode $GpuMode `
                -AppPort $AppPort `
                -RootPath $RootPath `
                -PackageFlavor $PackageFlavor
        }

        $composeArgs = @("up", "-d")
        if ($Build) {
            $composeArgs += "--build"
        }
        Invoke-TowerScoutCompose `
            -Engine $EngineName `
            -Build:$Build `
            -Gpu $GpuMode `
            -PodmanMachineName $PodmanMachineName `
            -ComposeArguments $composeArgs | Out-Host
        if ($script:TowerScoutComposeExitCode -ne 0) {
            Write-Host "TowerScout container startup failed. Check the selected engine, Compose provider, and local permissions."
            Write-TowerScoutHostDiagnostics -EngineName $EngineName
            return $script:TowerScoutComposeExitCode
        }

        Write-Host "Waiting for TowerScout readiness at $ReadinessUrl..."
        $deadline = (Get-Date).AddSeconds($ReadinessTimeoutSeconds)
        $lastState = ""
        $lastReadiness = $null

        while ((Get-Date) -lt $deadline) {
            $readiness = Get-TowerScoutReadiness -Url $ReadinessUrl
            $lastReadiness = $readiness

            if ($readiness.Reachable) {
                if ($readiness.State -in @("setup_required", "degraded", "ready")) {
                    Write-TowerScoutReadinessSummary -Readiness $readiness
                    if ($GpuMode -eq "on" -and -not (Test-TowerScoutCudaSelected -Readiness $readiness)) {
                        Write-Host "GPU mode is on, but TowerScout readiness did not report selected_device=cuda."
                        Write-Host "Check the image flavor, NVIDIA container access, and GPU overlay before continuing."
                        return 1
                    }

                    $launchSucceeded = $true
                    if (-not $NoBrowser) {
                        try {
                            Write-Host "Opening TowerScout in your browser..."
                            Start-Process $AppUrl
                        }
                        catch {
                            Write-Warning "TowerScout is ready, but the browser could not be opened automatically."
                            Write-Host "Open $AppUrl manually."
                        }
                    }
                    else {
                        Write-Host "Browser launch skipped. Open $AppUrl when ready."
                    }
                    return 0
                }

                if ($readiness.State -eq "fatal") {
                    Write-TowerScoutReadinessSummary -Readiness $readiness
                    Write-Host "Run scripts\logs.cmd for container logs or scripts\status.cmd for the current readiness payload."
                    return 1
                }
            }

            if ($readiness.State -ne $lastState) {
                Write-TowerScoutReadinessSummary -Readiness $readiness
                $lastState = $readiness.State
            }

            Start-Sleep -Seconds 2
        }

        Write-Warning "Timed out after $ReadinessTimeoutSeconds seconds waiting for TowerScout readiness."
        if ($lastReadiness -ne $null) {
            Write-TowerScoutReadinessSummary -Readiness $lastReadiness
        }
        Write-Host "Use scripts\status.cmd to inspect readiness, scripts\logs.cmd -Tail 200 for logs, or scripts\stop.cmd to stop TowerScout."
        return 2
    }
    finally {
        if ($null -ne $hostHelperReviewSession) {
            try {
                if (-not $launchSucceeded) {
                    Stop-TowerScoutHostHelperReviewSession `
                        -RootPath $RootPath `
                        -SessionId ([string] $hostHelperReviewSession.SessionId) `
                        -Process $hostHelperReviewSession.Process
                }
            }
            finally {
                if ($null -ne $hostHelperReviewSession.Process) {
                    $hostHelperReviewSession.Process.Dispose()
                }
            }
        }
    }
}

if ($MyInvocation.InvocationName -eq ".") {
    return
}

$hostHelperReviewEnabled = (
    ([string] $env:TOWERSCOUT_HOST_HELPER_REVIEW_ENABLED).Trim().ToLowerInvariant() -in
    @("1", "true", "yes", "on")
)
. "$PSScriptRoot\lib\TowerScoutCompose.ps1"
. "$PSScriptRoot\lib\TowerScoutHostHelperState.ps1"
$repoRoot = Get-TowerScoutRepoRoot
if ($hostHelperReviewEnabled -and -not (Test-Path -LiteralPath "$PSScriptRoot\lib\TowerScoutHostHelper.ps1" -PathType Leaf)) {
    Write-Warning "The deferred host helper is not included in this package. Continuing with normal startup."
    $hostHelperReviewEnabled = $false
}
if ($hostHelperReviewEnabled) {
    . "$PSScriptRoot\lib\TowerScoutHostHelper.ps1"
}
else {
    try {
        Clear-TowerScoutHostHelperSession -RootPath $repoRoot | Out-Null
    }
    finally {
        Clear-TowerScoutHostHelperBridgeEnvironment
    }
}

if ($TimeoutSeconds -lt 5) {
    throw "TimeoutSeconds must be at least 5."
}
if ($SessionMaxHours -lt 0) {
    throw "SessionMaxHours must be 0 or greater."
}

Initialize-TowerScoutEnvFile -RootPath $repoRoot
if ($portWasSpecified) {
    if ($null -eq $Port) {
        throw "Port must be an integer from 1 through 65535."
    }
    $Port = Set-TowerScoutPortEnvironment -Port $Port
}
else {
    $Port = Set-TowerScoutPortEnvironment -RootPath $repoRoot -DefaultPort 5000
}
$appUrl = "http://localhost:$Port"
$readinessUrl = "$appUrl/api/readiness"

$composeCommand = Get-TowerScoutComposeCommand `
    -Engine $Engine `
    -PodmanMachineName $PodmanMachineName
$effectiveEngine = [string] $composeCommand["Executable"]
$packageFlavor = Get-TowerScoutPackagePytorchFlavor -RootPath $repoRoot
if ([string]::IsNullOrWhiteSpace($packageFlavor)) {
    $packageFlavor = "source"
}
$env:TOWERSCOUT_CONTAINER_ENGINE = $effectiveEngine
if ($hostHelperReviewEnabled) {
    Save-TowerScoutHostHelperLaunchProfile `
        -Engine $effectiveEngine `
        -Gpu $Gpu `
        -AppPort $Port `
        -RootPath $repoRoot `
        -PackageFlavor $packageFlavor | Out-Null
}

Write-Host "Starting TowerScout with $effectiveEngine on $appUrl..."
Write-TowerScoutComposeProviderSummary `
    -Engine $effectiveEngine `
    -PodmanMachineName $PodmanMachineName
Set-TowerScoutGpuEnvironment -Gpu $Gpu -Build:$Build
Write-TowerScoutGpuModeSummary -EngineName $effectiveEngine -Gpu $Gpu -Build:$Build
Invoke-TowerScoutStaleContainerGuard -EngineName $effectiveEngine -SessionMaxHours $SessionMaxHours | Out-Null

$launchExitCode = Invoke-TowerScoutLaunchRuntime `
    -EngineName $effectiveEngine `
    -GpuMode $Gpu `
    -AppPort $Port `
    -RootPath $repoRoot `
    -PackageFlavor $packageFlavor `
    -AppUrl $appUrl `
    -ReadinessUrl $readinessUrl `
    -ReadinessTimeoutSeconds $TimeoutSeconds `
    -PodmanMachineName $PodmanMachineName `
    -Build:$Build `
    -HostHelperReviewEnabled:$hostHelperReviewEnabled `
    -NoBrowser:$NoBrowser
exit $launchExitCode
