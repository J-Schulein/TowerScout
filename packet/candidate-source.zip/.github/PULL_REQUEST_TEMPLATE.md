## Task / Issue Link

<!-- Link the relevant task, issue, or both -->
Closes:

## Summary

<!-- Briefly describe what changed -->

## Why

<!-- Explain why this change is needed -->

## Validation

<!-- Document the evidence that this change works -->

- [ ] Unit tests added or updated as needed
- [ ] Maintained smoke coverage run as needed
- [ ] Advisory validation noted if relevant
- [ ] Manual testing completed if relevant
- [ ] Long-running validation has a timeout, cleanup path, or documented advisory gap

Test results:

```text
```

## Risk / Rollback

Risk level:

Rollback plan:

## Documentation Updates

- [ ] Public guidance and sanitized evidence references updated as needed
- [ ] `README.md` updated if user-facing behavior changed
- [ ] `.github` guidance updated if architecture or workflow changed
- [ ] No stale legacy agent guidance introduced
- [ ] Complex logic is explained where needed

## Commit Checkpoint

- [ ] This branch has an intentional commit checkpoint for the completed slice

## Checklist

- [ ] Branch is focused on one task or one bounded task phase
- [ ] Changes follow the repo workflow policy
- [ ] Ready for review
